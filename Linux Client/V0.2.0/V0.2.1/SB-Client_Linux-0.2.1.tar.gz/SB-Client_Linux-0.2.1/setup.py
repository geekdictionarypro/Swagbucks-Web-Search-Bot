from distutils.core import setup

#This is a list of files to install, and where
#(relative to the 'root' dir, where setup.py is)
#You could be more specific.
files = ["things/*"]

setup(name = "SB-Client_Linux",
    version = "0.2.1",
    description = "Swagbucks Automated Search Machine to grab terms convert link",
    author = "GeekDictionary Pro",
    author_email = "jo.alen1@outlook.com",
    url = "n/a",
    #Name the folder where your packages live:
    #(If you have other packages (dirs) or modules (py files) then
    #put them into the package directory - they will be found 
    #recursively.)
    packages = ['Swagbucks-Linux'],
    #'package' package must contain files (see list above)
    #I called the package 'package' thus cleverly confusing the whole issue...
    #This dict maps the package name =to=> directories
    #It says, package *needs* these files.
    package_data = {'Swagbucks-Linux' : files },
    #'runner' is in the root.
    scripts = ["SB-WebAutoSearch"],
    license = "MIT License", 
    platforms  = "Linux - Clients", 
    classifiers=[
      'Development Status :: 6 - Release Stable (Long-Term)'
      'Intended Audience :: End Users/Systems based for Linux System',
      'License :: MIT Approved License',
      'Operating System :: POSIX :: All Linux Architectures',
      'Programming Language :: Python',
      'Topic :: Desktop Environment',
      'Topic :: Indexing/Search :: Automation'
])
