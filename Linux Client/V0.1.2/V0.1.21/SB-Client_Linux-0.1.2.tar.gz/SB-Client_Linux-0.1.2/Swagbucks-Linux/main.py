#!/usr/bin/env python3


"""
Swagbucks Searcher V0.1.21 - New Updates and Patch Release Notes coming soon. 
Copyright 2020 - Developed/Programmed by GeekDictionary. 

Linux Only format! 
"""

import webbrowser
import platform
import sys
from os import system, name 
import random 
import time 

### - Functions - ### 
def credits(): 
  print("Copyright 2020 - GeekDictionary Software LTD")
  print("Name of Programmer not included for anonymity")

def version(): 
  print("Linux Client " + platform.system() + " "  + platform.release())
  print("V0.1.2")

def print_introduction():
    print("Welcome to Swagobot Search, type in the correct command to being!")
    print("")
    print("**Note we only support these browsers, more are coming soon!**")
    print("1. Google Chrome")
    print("2. Mozilla Firefox")

def print_disclaimer_warning1(): 
  print("")
  print("Remember to add your file and name it *searchTerms* and then save it to the folder where the executable is to help it read and write addresses!")
  print("The program currently supports 10 terms, newer updates will raise the limit")

def print_disclaimer_warning2(): 
  print("")
  print("This program is not responsible for any liabilities to your account on Swagbucks.com/ please run this program wisely")
  print("Remember that in order to redeem swagbucks for searching the web, please make sure to login to your account")

def print_disclaimer_warning3(): 
  print("")
  print("This program is also NOT designed to defeat captchas as they keep on changing, please remember to complete the captcha and then report to the program to initiate the next one")
  print("Lastly, please do not copy the program or redistribute it in any other way as this program is free-to-use and is not monitized for any sort of action")

# Function browser_select() #
def run_item():
  # - User Input will then search the desired browser and execute code there - #
  user_input_1 = int(input("Type here> "))
  if (user_input_1 == 1):
    webbrowser.register(
            'chrome', None,
            webbrowser.BackgroundBrowser(
                "/usr/lib/google-chrome-stable "
            ))
    webbrowser.get('chrome').open(execution())
  elif (user_input_1 == 2): 
    webbrowser.register( 
      'firefox', None, 
      webbrowser.BackgroundBrowser( 
        "/usr/lib/firefox "
      ))
    webbrowser.get('firefox').open(execution())
  else: 
    print("Exception occured, Error 1x1 - User Input not recognized! [External Error]")
    sys.exit(1)

# -  Sequence Variables - # 
seq_1 = random.randint(0, 30)
seq_2 = random.randint(31, 60)
seq_3 = random.randint(seq_1, seq_2)
seq_4 = random.randint(0, 10)
seq_5 = random.randint(11, 50)
seq_6 = random.randint(51, 75)
seq_7 = random.randint(76, 100)

# - Function - # 
def clear(): 
  
    # for windows 
    if name == 'nt': 
        _ = system('cls') 
  
    # for mac and linux(here, os.name is 'posix') 
    else: 
        _ = system('clear')

def progress_bar_print(): 
  if 0 <= seq_3 <= 30:
    print("[=....................1%.................]")
    time.sleep(3)
    if (0 <= seq_4 <= 10): 
      clear() 
      print("[=....................2%.................]") 
      time.sleep(3)
      clear() 
      print("[==...................6%.................]") 
      time.sleep(2)
      clear()
      print("[===..................9%.................]")
      time.sleep(seq_4)
      clear()
      print("[===..................10%.................]")
    else: 
      print("Exception occured, Error 0x1 - Cannot complete prerequisites! (internal error)")
      sys.exit(1) 
    if (11 <= seq_5 <= 50):
      clear() 
      print("[=====................13%.................]")
      time.sleep(seq_1)
      clear() 
      print("[==========..........28%.................]")
      time.sleep(4)
      clear() 
      print("[=============.......39%.................]")
      time.sleep(seq_4)
      clear() 
      print("[==================..50%.................]")
      time.sleep(2)
    else: 
      print("Exception occured, Error 0x2 - Cannot complete prerequisites (internal error)")
      sys.exit(1) 
    if (51 <= seq_6 <= 75): 
      clear() 
      print("[====================58%.................]")
      time.sleep(3)
      clear() 
      print("[=========================.72%...........]")
      time.sleep(4)
      clear() 
      print("[==========================75%...........]")
    else: 
      print("Exception occured, Error 0x3 - Cannot complete prerequisites! (internal error)")
    if (76 <= seq_7 <= 100): 
      clear() 
      print("[==============================82%......]")
      time.sleep(5)
      clear() 
      print("[==================================98%..]")
      time.sleep(5)
      clear() 
      print("[====================================100%]")
      print("Operation completed successful, please wait...")
      clear() 
    else: 
      print("Exception occured, Error 0x4 - Cannot complete prerequisites (internal error)")
  elif 31 <= seq_3 <= 60:
    if(0 <= seq_4 <= 10): 
      clear()
      print("[=....................1%.................]")
      time.sleep(3)
      clear()
      print("[===..................4%.................]")
      time.sleep(2)
      print("[======...............8%.................]")
    else: 
      print("Exception occured, Error 0x5 - Cannot complete prerequisites! (internal error)")
      sys.exit(1) 
    if (11 <= seq_5 <= 50): 
      clear() 
      print("[========............15%.................]")
      time.sleep(seq_1)
      clear() 
      print("[===========.........28%.................]")
      time.sleep(2) 
      clear()
      print("[=============.......45%.................]")
      time.sleep(2)
    else: 
      print("Exception occured, Error 0x6 - Cannot complete pre-requisties! (internal error)")
      sys.exit(1) 
    if (51 <= seq_6 <= 75): 
      clear() 
      print("[====================58%.................]")
      time.sleep(3)
      clear() 
      print("[=========================.72%...........]")
      time.sleep(4)
      clear() 
      print("[==========================75%...........]")
    else: 
      print("Exception occured, Error 0x7 - Cannot complete prerequisites! (internal error)")
      sys.exit(1)
    if (76 <= seq_7 <= 100): 
      clear() 
      print("[=========================75%............]")
      time.sleep(4)
      clear() 
      print("[================================94%.....]")
      time.sleep(3)
      clear() 
      print("[====================================100%]")
      time.sleep(2)
      clear()
      print("Operation completed successful, please wait...")
      time.sleep(3)
      clear()
  else: 
    print("Exception Error 1x0 - Program couldn't complete operation")
    print("If you see this error message, please contact me at [dunbardixie1231@tutanota.com]. Information about error codes will be updated soon and a website will be made possible after a few releases")

def execution():
  fileUpload = input("Paste File Directory>")
  terms = []
  with open(fileUpload, 'rt') as myfile: 
    for terms in myfile:
      terms = myfile.read().split()
      print(terms[0])
      print(terms[1])
      print(terms[2])
      print(terms[3])
      print(terms[4])
      print(terms[5])
      print(terms[6])
      print(terms[7])
      print(terms[8])
      print(terms[9])
      time.sleep(1)
      confirm = input("Are these the terms above? [type y or n]>")
      if (confirm == "y" or "Y"): 
        address1 = "https://www.swagbucks.com/?f=55&q=" + terms[0]
        webbrowser.open_new_tab(address1 + 'doc/')
        webbrowser.open_new(address1)
        # - This then repeats to ensure that the program runs 10 address' to the desired browser. Swagbucks adds a new feature where the user might have to have less searches in a few moments!- # 
        confirm_next_1 = input("Next one? {type y or n} >")
        if (confirm_next_1 == "y" or "Y"):
          print("Starting in 5 seconds")
          time.sleep(5)
          address1 = "https://www.swagbucks.com/?f=55&q=" + terms[1]
          webbrowser.open_new_tab(address1 + 'doc/')
          confirm_next_2 = input("Next one? {type y or n} >")
          if (confirm_next_2 == "y" or "Y"):
            print("Starting in 5 seconds")
            time.sleep(5)
            address1 = "https://www.swagbucks.com/?f=55&q=" + terms[2]
            webbrowser.open_new_tab(address1 + 'doc/')
            confirm_next_3 = input("Next one? {type y or n} >")
            if (confirm_next_3 == "y" or 'Y'):
              print("Starting in 5 seconds")
              time.sleep(5)
              address1 = "https://www.swagbucks.com/?f=55&q=" + terms[3]
              webbrowser.open_new_tab(address1 + 'doc/')
              confirm_next_3 = input("Next one? {type y or n} >")
              if (confirm_next_3 == "y" or 'Y'):
                print("Starting in 5 seconds")
                time.sleep(5)
                address1 = "https://www.swagbucks.com/?f=55&q=" + terms[4]
                webbrowser.open_new_tab(address1 + 'doc/')
                confirm_next_4 = input("Next one? {type y or n} >")
                if (confirm_next_4 == "y" or 'Y'):
                  print("Starting in 5 seconds")
                  time.sleep(5)
                  address1 = "https://www.swagbucks.com/?f=55&q=" + terms[5]
                  webbrowser.open_new_tab(address1 + 'doc/')
                  confirm_next_5 = input("Next one? {type y or n} >")
                  if (confirm_next_5 == "y" or 'Y'):
                    print("Starting in 5 seconds")
                    time.sleep(5)
                    address1 = "https://www.swagbucks.com/?f=55&q=" + terms[6]
                    webbrowser.open_new_tab(address1 + 'doc/')
                    confirm_next_6 = input("Next one? {type y or n} >")
                    if (confirm_next_6 == "y" or 'Y'):
                      print("Starting in 5 seconds")
                      time.sleep(5)
                      address1 = "https://www.swagbucks.com/?f=55&q=" + terms[7]
                      webbrowser.open_new_tab(address1 + 'doc/')
                      confirm_next_7 = input("Next one? {type y or n} >")
                      if (confirm_next_7 == "y" or "Y"): 
                         print("Starting in 5 seconds")
                         time.sleep(5)
                         address1 = "https://www.swagbucks.com/?f=55&q=" + terms[8]
                         webbrowser.open_new_tab(address1 + 'doc/')
                         confirm_next_8 = input("Next one? {type y or n} >")
                         if (confirm_next_8 == "y" or "Y"):
                             print("Starting in 5 seconds")
                             time.sleep(5)
                             address1 = "https://www.swagbucks.com/?f=55&q=" + terms[9]
                             webbrowser.open_new_tab(address1 + 'doc/')
                         else: 
                            print("Sorry about that, redirectng program to menu in 5 seconds!")
                            time.sleep(5)
                            clear() 
                            user_menu()
                      else: 
                        print("Sorry about that, redirectng program to menu in 5 seconds!")
                        time.sleep(5)
                        clear() 
                        user_menu()
                    else: 
                      print("Sorry about that, redirectng program to menu in 5 seconds!")
                      time.sleep(5)
                      clear() 
                      user_menu() 
                else: 
                  print("Sorry about that, redirectng program to menu in 5 seconds!")
                  time.sleep(5)
                  clear() 
                  user_menu() 
              else: 
                print("Sorry about that, redirectng program to menu in 5 seconds!")
                time.sleep(5)
                clear() 
                user_menu() 
            else: 
              print("Sorry about that, redirectng program to menu in 5 seconds!")
              time.sleep(5)
              clear() 
              user_menu() 
          else: 
            print("Sorry about that, redirectng program to menu in 5 seconds!")
            time.sleep(5)
            clear() 
            user_menu() 
        else: 
          print("Sorry about that, redirectng program to menu in 5 seconds!")
          time.sleep(5)
          clear() 
          user_menu() 
      else: 
        print("Sorry about that, redirecting program to menu in 5 seconds!")
        time.sleep(5) 
        clear() 
        user_menu() 
    else: 
      print("Please either re-attach another file and name it searchTerms or either re-do the list")
      print("Redirecting you back to the menu in 15 seconds or type 'continue'")
      validate = input(">")
      if (validate == 'continue' or "Continue"): 
        clear() 
        user_menu() 
      else: 
        time.sleep(15) 
        clear() 
        user_menu() 

# - first function to initilize - # 
def user_autoIntro(): 
  print("Welcome user to the Swagbucks Search Automation Bot Program")
  print("")
  print("This aint a virus so don't worry, however illegal use of the program could get you in trouble. Remember to use this program for its intended use only.")
  print("")
  print("All copyright is reserved to the respectful programmer {{geekdictionary}}, please make sure to not redistribute as this program is free-to-use and is not meant for monitary actions")
  print("")
  print("If by chance you find a program like this that asks for a license, subscription, or to pay for the program, please remove it immediately and download the official one from the two sources GitHub and sourceForge! Find my username geekdictionary to learn more about the program.")
  print("")
  print("Anyways, now that I've gotten rid of the most basic introduction, let's begin")
  print("Clearing in 10 seconds or type 'continue'")
  validate = input(">")
  if (validate == "continue" or "Continue"): 
    clear() 
    user_menu() 
  else: 
    time.sleep(10)
    clear() 
    user_menu()

def user_menu(): 
  print("Menu")
  print(" - 1. Start")
  print(" - 2. Warning/Disclaimer")
  print(" - 3. Credits")
  print(" - 4. Version")
  print(" - 5. Exit")
  print("Type in the correct number to being. Don't include a dot!")
  input_query_1 = int(input(">"))
  
  # - Menu Validation - # 
  if (input_query_1 == 1): 
    clear() 
    print_introduction()
    run_item()
  elif (input_query_1 == 2): 
    clear() 
    print_disclaimer_warning1()
    time.sleep(3)
    clear() 
    print_disclaimer_warning1()
    time.sleep(3)
    clear()
    print_disclaimer_warning1()
    user_menu
  elif (input_query_1 == 3): 
    clear() 
    credits()
    time.sleep(3)
    clear() 
    user_menu()
  elif (input_query_1 == 4): 
    clear() 
    version() 
    time.sleep(3) 
    clear() 
    user_menu() 
  elif (input_query_1 == 5): 
    print("Are you sure you want to exit?")
    input_query_2 = input(">")
    if (input_query_2 == "Yes" or "yes"): 
      clear()
      print("exiting program in 3 seconds")
      time.sleep(3)
      sys.exit(1)
    else: 
      clear()
      print("You will be redirected back to menu!")
      time.sleep(2)
      user_menu() 
  else: 
    print("Exception occured - Error 1x2 - Wrong input for Menu (Redirecting)")
    time.sleep(2)
    clear()
    user_menu() # - Redirect back again - # 
# - Pre Environment - # 
print("Loading up Swagbucks Search Automater, please wait...")
print("")
progress_bar_print()

# - Main Program - # 
user_autoIntro()
user_menu()
